﻿using FileData.Models;
using Microsoft.AspNetCore.Mvc;

namespace FileData.Controllers
{
    public class HorariosController : Controller
    {
        private readonly BdDataFileContext _context;

        public HorariosController(BdDataFileContext context)
        {
            _context = context;
        }

        // 🔹 GET: Mostrar formulario
        [HttpGet]
        public IActionResult RegistrarHorario()
        {
            ViewBag.Empleados = _context.Empleados.ToList();

            return PartialView("RegistrarHorario");
        }

        // 🔹 POST: Guardar datos
        [HttpPost]
        public IActionResult RegistrarHorario(IFormCollection form)
        {
            try
            {
                // 1️⃣ Validar que el usuario esté logueado
                if (!User.Claims.Any(c => c.Type == "IdUsuario"))
                    return BadRequest(new { mensaje = "Debes iniciar sesión antes de registrar un horario." });

                int idUsuarioLogueado = int.Parse(User.Claims.First(c => c.Type == "IdUsuario").Value);

                // 2️⃣ Leer datos del formulario
                int idEmpleado = int.Parse(form["IdEmpleado"]);
                DateOnly fechaInicio = DateOnly.Parse(form["FechaInicio"]);
                TimeOnly horaEntrada = TimeOnly.Parse(form["HoraEntrada"]);
                TimeOnly? horaSalida = string.IsNullOrEmpty(form["HoraSalida"]) ? null : TimeOnly.Parse(form["HoraSalida"]);
                string observaciones = form["Observaciones"];

                // 3️⃣ Validaciones

                // Fecha >= hoy
                if (fechaInicio < DateOnly.FromDateTime(DateTime.Now))
                    return BadRequest(new { mensaje = "La fecha de inicio no puede ser anterior a hoy." });

                // Si hay horaSalida, validar máximo 8 horas
                if (horaSalida.HasValue)
                {
                    var duracion = (horaSalida.Value.ToTimeSpan() - horaEntrada.ToTimeSpan()).TotalHours;
                    if (duracion > 8)
                        return BadRequest(new { mensaje = "El horario no puede exceder 8 horas." });
                    if (duracion <= 0)
                        return BadRequest(new { mensaje = "La hora de salida debe ser mayor que la de entrada." });
                }

                // Validar que no exista horario para el mismo empleado y fecha
                bool existeHorario = _context.Horarios.Any(h => h.IdEmpleado == idEmpleado && h.FechaInicio == fechaInicio);
                if (existeHorario)
                    return BadRequest(new { mensaje = "Ya existe un horario registrado para este empleado en esa fecha." });

                // 4️⃣ Crear el horario
                var horario = new Horario
                {
                    IdEmpleado = idEmpleado,
                    FechaInicio = fechaInicio,
                    HoraEntrada = horaEntrada,
                    HoraSalida = horaSalida,
                    Observaciones = observaciones,
                    UsuarioRegistro = idUsuarioLogueado,
                    FechaRegistro = DateTime.Now
                };

                _context.Horarios.Add(horario);
                _context.SaveChanges();

                return Ok(new { mensaje = "Horario registrado correctamente." });
            }
            catch (Exception ex)
            {
                // Mensaje real para depuración
                return BadRequest(new { mensaje = "Error al registrar horario: " + ex.Message });
            }
        }



    }
}

