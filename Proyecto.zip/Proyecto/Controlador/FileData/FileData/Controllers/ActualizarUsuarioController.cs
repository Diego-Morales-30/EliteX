﻿using FileData.Models;
using Microsoft.AspNetCore.Mvc;

namespace FileData.Controllers
{
    public class ActualizarUsuarioController : Controller
    {
        private readonly BdDataFileContext _context;  // ← SOLO UNA VEZ

        public ActualizarUsuarioController(BdDataFileContext context)
        {
            _context = context;  // ← Y se asigna aquí
        }

        [HttpPost]
        public JsonResult ActualizarUsuarioAjax([FromForm] Usuario model)
        {
            if (model == null || model.IdUsuario == 0)
            {
                return Json(new { success = false, message = "Datos inválidos." });
            }

            var usuario = _context.Usuarios.FirstOrDefault(u => u.IdUsuario == model.IdUsuario);
            if (usuario == null)
            {
                return Json(new { success = false, message = "Usuario no encontrado." });
            }

            usuario.Usuario1 = model.Usuario1;
            usuario.Contrasena = model.Contrasena;
            usuario.Cargo = model.Cargo;

            try
            {
                _context.Update(usuario);
                _context.SaveChanges();
                return Json(new { success = true, message = "Usuario actualizado correctamente." });
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "Error: " + ex.Message });
            }
        }
    }
}
